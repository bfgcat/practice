This file contains the responses to Turbine's Release Engineer Test from

Brian Gillespie
Brian.Gillespie@comcast.net
978-500-9915
returned on 4 Oct 2010


There are ten files in this zip file "ResponseTurbineRETest.zip":

PerlExample1.pl - Perl file created to resolve 1) from PerlQuestion1.txt

PerlExample1_part2.txt - response to question 2) from file PerlQuestion1.txt

PerlExample1.out - output from running perl file PerlExample1.pl

SettingsTEST.xml - originally supplied file

SettingsTESTfixed.xml - The editted copy of SettingsTEST.xml, to resolve
	apparent error in file.

PerlExample2.pl - Perl file created to resolve 1) from PerlQuestion2.txt

machineline - Copy.txt - copy of the original machinelist.txt file.

machinelist.txt - modified result of running PerlExample2.pl

Build System Test Response.doc - Response to "Build system test.txt" question
	includes copy of original question/file.

README.txt - this file.
